#include<iostream>
using namespace std;
int main()
{
    int  num,den,result;
    cout<<"ENTER NUMERATOR AND DENOMINATOR";
    cin>>num;
    cin>>den;
    
    
    try
    {
        if(den==0)
        {
            throw den;
        }
        result=num/den;
    }
        catch(int  ex)
        {
            cout<<"DIVIDE BY ZERO NOT ALLOWED "<<ex;
            
        }
        return 0;

}

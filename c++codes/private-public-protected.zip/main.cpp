#include<iostream>
using namespace std;
class demo
{
    public:
    int x;
    protected:
    int y;
    private:
    int z;
};
class demo2 : public demo
{
    public:
    void show()
    {
         x=10;
         y=20;
         z=30;
    }
};
int main()
{
    demo2 obj1;
    obj1.show();
}
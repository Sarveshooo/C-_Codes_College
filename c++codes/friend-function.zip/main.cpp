#include<iostream>
using namespace std;
class kanha;
class sarvesh
{
    private:
    int money=100;
    friend void abhish(sarvesh,kanha);
};
class kanha
{
    private:
    int money=200;
    friend void abhish(sarvesh,kanha);
};
void abhish (sarvesh r1,kanha r2)
{
    cout<<"SUM OF MONEY FROM SARVESH AND KANHA"<<r1.money+r2.money;
}
int main()
{
    sarvesh obj1;
    kanha obj2;
    abhish(obj1,obj2);
}
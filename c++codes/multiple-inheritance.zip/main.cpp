#include<iostream>
using namespace std;
class a
{
    public:
    void show1()
    {
        cout<<"in a ";
    }
};
class b
{
    public:
    void show2()
    {
        cout<<"in b";
    }
};
class c : public a,public b
{
    public:
    void show3()
    {
        cout<<"in c";
        
    }
};
int main()
{
    c obj1;
    obj1.show3();
    obj1.show2();
    obj1.show1();
}
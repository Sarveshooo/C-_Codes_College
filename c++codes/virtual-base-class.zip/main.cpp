#include<iostream>
using namespace std;
class a
{
    public :
    int x;
};
class b:virtual public a
{
    public:
    int y;
};
class c:virtual public a
{
    public:
    int z;
};
class d:public b,public c
{
    public:
    int show()
    {
        return x+y+z;
    }
};
int main()
    {
        d obj1;
        obj1.x=10;
        obj1.y=20;
        obj1.z=30;
        cout<<"sum"<<obj1.show();
    }
/*#include<iostream>1
using namespace std;
template<typename t , typename g>
g add (t x ,g y)
{
    return(x+y);
    
}
int main()
{
    cout<<"addition is "<<add<int,float>(4566,56.9909f)<<endl;
}



#include<iostream>2
using namespace std;
template<typename t ,typename g>
g mul(t x, g y)
{
    return(x*y);
}
int main()
{
    cout<<"multiplication is "<<mul<int,float>(344,45.666f);
}
*/



/*
#include<iostream>3
using namespace std;
template<typename t>
t add (t x ,t y )
{
    return(x+y);
}
int main()
{
    cout<<"additon is "<<add<int>(34,56)<<endl;
}

/*

#include<iostream>4
using namespace std;
template<typename t>
t mul (t x ,t y)
{
    return(x*y);
}
int main()
{
    cout<<"multiplication is "<<mul<int>(34,56);
}*/

/*


#include<iostream>5
using namespace std;
template<typename t ,typename g>
//template<typename q ,typename w>
g add (t x ,g y)
//w mul (t q ,g w)
{
    return(x+y);
    //return(q*w);
    
}
int main()
{
    cout<<"addition is "<<add<int,float>(3444,56.6f)<<endl;
    ///cout<<"multiply is "<<mul<int,float>(3444,56.6)<<endl;
    
}
*/

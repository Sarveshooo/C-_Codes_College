#include<iostream>
using namespace std;
class demo
{
    public:
    virtual void show()=0;
};
class demo2:public demo
{
    public:
    void show()
    {
        cout<<"in demo 2";
    }
    
};
int main()
{
    demo2 obj1;
    obj1.show();
}